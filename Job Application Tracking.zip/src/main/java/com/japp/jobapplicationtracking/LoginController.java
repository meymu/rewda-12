package com.japp.jobapplicationtracking;

import com.japp.jobapplicationtracking.Model.Applicant;
import com.japp.jobapplicationtracking.Model.Company;
import com.japp.jobapplicationtracking.Model.DatabaseDriver;
import com.japp.jobapplicationtracking.Model.Model;
import com.japp.jobapplicationtracking.Views.UserRole;
import com.japp.jobapplicationtracking.Views.View;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    public Button button_login;
    public Button button_sign_up;
    public TextField tf_username;
    public TextField tf_password;
    public  Label error_lbl;

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle) {

        button_sign_up.setOnAction(event ->onSignUP() );
        button_login.setOnAction(event->onlogin());
    }//end of method

    public void onSignUP(){
        Stage stage = (Stage) error_lbl.getScene().getWindow();
        Model.getInstance().getView().showRoleWindow();
        Model.getInstance().getView().closeStage(stage);
    }//end of method

    public  void onlogin() {
        Stage stage = (Stage) error_lbl.getScene().getWindow();
      if(tf_password.getText().isEmpty() || tf_password.getText().isEmpty()){
          error_lbl.setText("Please Enter password and username");
      }else {
          validateLogin();
          if (Model.getInstance().getView().getRole() == UserRole.APPLICANT) {
              Applicant.username=tf_username.getText();
              Applicant.password=tf_password.getText();
              Model.getInstance().getDatabaseDriver().getApplicantData();
              Model.getInstance().getView().showApplicantWindow();
              Model.getInstance().getView().closeStage(stage);


          } else if (Model.getInstance().getView().getRole() == UserRole.COMPANY) {
              Company.username=tf_username.getText();
              Company.password=tf_password.getText();
              Model.getInstance().getDatabaseDriver().getCompanyData();
              Model.getInstance().getView().showCompanyWindow();
              Model.getInstance().getView().closeStage(stage);

          } else {
              tf_username.setText("");
              tf_password.setText("");
              error_lbl.setText("No Such Lognin Credential");
          }
      }
    }//end of method
    private void validateLogin(){

        String verifyCompanylogin="SELECT count(1) FROM company WHERE username='"+tf_username.getText()+"'AND password='"+tf_password.getText()+"'";
        String verifyApplicantlogin="SELECT count(1) FROM applicant WHERE username='"+tf_username.getText()+"'AND password='"+tf_password.getText()+"'";

        try {

    Connection conn=Model.getInstance().getDatabaseDriver().getDatabaseConnection();
    Statement statement=conn.createStatement();
    ResultSet resultSet1=statement.executeQuery(verifyCompanylogin);
            int count = 0;
            if (resultSet1.next()) {
                 count = resultSet1.getInt(1);
                resultSet1.close();
            }
            if (count==1){
                Model.getInstance().getView().setRole(UserRole.COMPANY);
            }
        ResultSet resultSet2=statement.executeQuery(verifyApplicantlogin);
            if (resultSet2.next()) {
                count = resultSet2.getInt(1);
                resultSet2.close();
            }
            if (count== 1) {
                Model.getInstance().getView().setRole(UserRole.APPLICANT);

            }

} catch (SQLException e) {
    e.printStackTrace();
}

    }//end of method

}
