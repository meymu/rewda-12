package com.japp.jobapplicationtracking;

import com.japp.jobapplicationtracking.Model.DatabaseDriver;
import com.japp.jobapplicationtracking.Model.Model;
import javafx.application.Application;
import javafx.stage.Stage;

import java.sql.Connection;

public class App extends Application {

        @Override
        public void start(Stage stage){

            Model.getInstance().getView().showLoginWindow();
        }

    }


