package com.japp.jobapplicationtracking.Views;

public enum CompanyMenuOption {
    COMPANY_DASHBOARD,
    SETSCHEDULE,
    COMPANY_PROFILE

}
