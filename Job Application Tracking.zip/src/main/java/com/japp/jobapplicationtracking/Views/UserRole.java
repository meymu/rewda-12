package com.japp.jobapplicationtracking.Views;

public enum UserRole {
    COMPANY,
    APPLICANT
}
