package com.japp.jobapplicationtracking.Views;

import com.japp.jobapplicationtracking.Applicant.ApplicantController;
import com.japp.jobapplicationtracking.Company.CompanyController;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class View {
    private UserRole role;
    private final ObjectProperty<ApplicantMenuOption> applicantSelectedMenuItem;
    private final ObjectProperty<CompanyMenuOption> companySelectedMenuItem;
    private AnchorPane DashboardView;
    private AnchorPane ProfileView;
    private AnchorPane JobDescriptionView;
    private AnchorPane CompanyDashboardView;

    private AnchorPane SetScheduleView;


    private AnchorPane CompanyProfileView;
   private AnchorPane JobPostDescriptionView;


    public View(){
        this.role=null;
        this.applicantSelectedMenuItem= new SimpleObjectProperty<>();
        this.companySelectedMenuItem=new SimpleObjectProperty<>();
    }
    public UserRole getRole(){
        return role;
    }
    public void setRole(UserRole role){
        this.role=role;
    }
    public ObjectProperty<ApplicantMenuOption> getApplicantSelectedMenuItem(){

        return applicantSelectedMenuItem;
    }
    public ObjectProperty<CompanyMenuOption> getCompanySelectedMenuItem(){

        return companySelectedMenuItem;
    }
    public AnchorPane getCompanyProfileView() {
        if(CompanyProfileView==null){
            try{
                CompanyProfileView=new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Company/CompanyProfile.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return CompanyProfileView;
    }
    public AnchorPane getSetScheduleView() {
        if(SetScheduleView==null){
            try{
                SetScheduleView=new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Company/CSetSchedule.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return SetScheduleView;
    }
    public AnchorPane getCompanyDashboardView() {
        if(CompanyDashboardView==null){
            try{
                CompanyDashboardView=new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Company/CompanyDashboard.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return CompanyDashboardView;
    }

    public AnchorPane getProfileView() {
        if(ProfileView==null){
            try{
                ProfileView=new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Applicant/ApplicantProfile.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return ProfileView;
    }

    public void ApplicationWindow() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Applicant/Application.fxml"));
        createStage(loader);
    }//end of the method


    public AnchorPane getDashboardView() {
        if(DashboardView==null){
            try{
                DashboardView=new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Applicant/ApplicantDashboard.fxml")).load();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return DashboardView;
    }



    public void showLoginWindow() {
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Login.fxml"));
        createStage(loader);
    }//end of the method
    public void companyShowSignupWindow() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Company/CompanySignUp.fxml"));
        createStage(loader);
    }//end of the method
    public void applicantShowSignupWindow() {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Applicant/ApplicantSignUp.fxml"));
        createStage(loader);
    }//end of the method

    public void showRoleWindow() {
        FXMLLoader loader= new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Role.fxml"));
        createStage(loader);
    }//end of the method

    private void createStage(FXMLLoader fxmlLoader){
        Scene scene=null;
        try{
            scene=new Scene(fxmlLoader.load());
        }catch (Exception e){
            e.printStackTrace();
        }
        Stage stage=new Stage();
        stage.setScene(scene);
        stage.setTitle("Job Application Tracking System");
        stage.show();

    }
    public void showApplicantWindow(){
        FXMLLoader loader=new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Applicant/Applicant.fxml"));
        ApplicantController applicantController= new ApplicantController();
        loader.setController(applicantController);
        createStage(loader);
    }


    public void showCompanyWindow(){
        FXMLLoader loader=new FXMLLoader(getClass().getResource("/com/japp/jobapplicationtracking/Company/Company.fxml"));
       CompanyController companyController= new CompanyController();
        loader.setController(companyController);
        createStage(loader);
    }

    public void closeStage(Stage stage){
        stage.close();
    }

}

