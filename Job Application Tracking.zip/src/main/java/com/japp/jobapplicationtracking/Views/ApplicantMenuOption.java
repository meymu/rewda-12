package com.japp.jobapplicationtracking.Views;

public enum ApplicantMenuOption {
    APPLICANT_DASHBOARD,
    APPLICANT_PROFILE
}
