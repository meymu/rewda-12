package com.japp.jobapplicationtracking.Applicant;

import com.japp.jobapplicationtracking.Model.Applicant;
import com.japp.jobapplicationtracking.Model.Application;
import com.japp.jobapplicationtracking.Model.Company;
import com.japp.jobapplicationtracking.Model.Model;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.sql.*;
import java.util.ResourceBundle;

public class ApplicationController implements Initializable {

    public Button Upload_btn;
    public Button back_btn;
    public Button submit_btn;
    public Label cname_lbl;
    public Label apply_lbl;
    public Label cheadquarter_lbl;
    private String filePath=null;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cname_lbl.setText(Company.companyname);
        cheadquarter_lbl.setText(Company.companyname);

         Upload_btn.setOnAction(event ->onUpload() );
        back_btn.setOnAction(event -> {
            Stage stage = (Stage)apply_lbl.getScene().getWindow();
            Model.getInstance().getView().showApplicantWindow();
            Model.getInstance().getView().closeStage(stage);
        });
     submit_btn.setOnAction((event ->onSubmit() ));
    }//end of method
    private void onUpload(){
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extensionFilter = new FileChooser.ExtensionFilter(
                "Documents (*.doc, *.docx, *.pdf, *.ppt, *.pptx)", "*.doc", "*.docx", "*.pdf", "*.ppt", "*.pptx");
        fileChooser.getExtensionFilters().add(extensionFilter);
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            filePath = selectedFile.getAbsolutePath();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setHeaderText("Document Uploaded!");
                alert.setContentText("Successfully Uploaded.");
                ButtonType okButton = new ButtonType("OK");
                alert.getButtonTypes().setAll(okButton);
                alert.showAndWait();

        }
    }//end of method
    private void onSubmit(){

        String sql="insert into application(coverletter,applicantusername,jobpostid)values (?,?,?)";
        Connection conn=Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        try {
            if(filePath==null){
                Alert alert=new Alert(Alert.AlertType.ERROR) ;
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please upload Cover letter");
                alert.showAndWait();
            }else {
                    filePath = filePath.replace("\\", "\\\\");

                File file=new File(filePath);
                String check="SELECT applicantusername from application where applicantusername='"+Applicant.username+"'AND jobpostid='"+Applicant.postid+"'";
                Statement stat=conn.createStatement();
                ResultSet resultSet=stat.executeQuery(check);
                if(resultSet.next()){
                    Alert alert=new Alert(Alert.AlertType.ERROR) ;
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("You already apply ");
                    alert.showAndWait();
                    resultSet.close();
                }else {


            PreparedStatement preparedStatement=conn.prepareStatement(sql);
            preparedStatement.setBytes(1, Files.readAllBytes(file.toPath()));
            preparedStatement.setString(2, Applicant.username);
            preparedStatement.setString(3, Applicant.postid);
            preparedStatement.executeUpdate();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setHeaderText("Data Saved!");
                alert.setContentText("Successfully Submitted.");
                ButtonType okButton = new ButtonType("OK");
                alert.getButtonTypes().setAll(okButton);
                alert.showAndWait();

        }}
        } catch (SQLException e) {
           e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}//end of method
