package com.japp.jobapplicationtracking.Applicant;

import com.japp.jobapplicationtracking.Model.Model;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

public class ApplicantController implements Initializable {
    public BorderPane ApplicantParent;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Model.getInstance().getView().getApplicantSelectedMenuItem().addListener((observableValue, oldValue, newValue) -> {
            switch (newValue){
                case APPLICANT_PROFILE->ApplicantParent.setCenter(Model.getInstance().getView().getProfileView());
               default -> ApplicantParent.setCenter(Model.getInstance().getView().getDashboardView());
            }
        });
    }
}
