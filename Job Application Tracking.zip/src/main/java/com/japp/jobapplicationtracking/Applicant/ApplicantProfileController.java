package com.japp.jobapplicationtracking.Applicant;

import com.japp.jobapplicationtracking.Model.Applicant;
import com.japp.jobapplicationtracking.Model.DatabaseDriver;
import com.japp.jobapplicationtracking.Model.Model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.ResourceBundle;

public class ApplicantProfileController implements Initializable{


    public TextField fullname_tf;
    public TextField workexpriance_tf;

    public ChoiceBox<String> cb_qualification;
    public ChoiceBox<Integer> age_cb;

    private final Integer[] ageList={18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49};
    private final String[] qualificationList={"certificate" ," Degree","Master","PHD"};
    public RadioButton female_rb,male_rb;
    public Button save_btn;
    public Button delete_btn;
    public ImageView profilePicture;
    public Button addPicture_btn;
    public TextField phoneNo_tf;
    public TextField areaofspecialization_Tf;
    private  Image profileImage;



    @Override

        public void initialize(URL url, ResourceBundle resourceBundle) {
        setData();
        age_cb.getItems().addAll(this.ageList);
        cb_qualification.getItems().addAll(this.qualificationList);
         female_rb.setOnAction(this::getGender);
         male_rb.setOnAction(this::getGender);
        addPicture_btn.setOnAction(event->handleSetProfilePicture());
        save_btn.setOnAction(event -> onSave());
        delete_btn.setOnAction(event->onDelete());
    }
    private void setData(){
        Model.getInstance().getDatabaseDriver().getCompanyData();
        fullname_tf.setText(Applicant.fullname);
        workexpriance_tf.setText(String.valueOf(Applicant.workexperience));
        phoneNo_tf.setText(Applicant.phoneNum);
        areaofspecialization_Tf.setText(Applicant.areaofspecialization);
        String url="file:"+Applicant.profilepicture;
        if (Applicant.profilepicture!=null){
            profileImage = new Image(url,173,172,false,true);
            profilePicture.setImage(profileImage);
        }
    }
    private void onDelete(){
        Alert alert;
        Stage stage = (Stage)areaofspecialization_Tf.getScene().getWindow();
        DatabaseDriver driver = new DatabaseDriver();
        Connection conn = driver.getDatabaseConnection();
        String sql = "DELETE FROM applicant WHERE username=?";
        String sql2 = "DELETE FROM application WHERE applicantusername=?";
        try {PreparedStatement statement = conn.prepareStatement(sql);
            PreparedStatement statement2 = conn.prepareStatement(sql2);
            alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Message");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to delete your profile");
            Optional<ButtonType> option = alert.showAndWait();

            if (option.get().equals(ButtonType.OK)) {
                statement2.setString(1,Applicant.username);
                statement.setString(1, Applicant.username);
                statement2.executeUpdate();
                statement.executeUpdate();
                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("Successfully deleted");
                alert.showAndWait();
                Model.getInstance().getView().applicantShowSignupWindow();
                Model.getInstance().getView().closeStage(stage);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//end of method

    private void getGender(ActionEvent event){
        if(female_rb.isSelected()){
            Applicant.gender= "F";
        }else if(male_rb.isSelected()){
            Applicant.gender= "M";
        }
    }//end of method

    private void onSave(){
        Applicant.areaofspecialization =areaofspecialization_Tf.getText();
        Applicant.fullname = fullname_tf.getText();
        Applicant.phoneNum=phoneNo_tf.getText();
        Applicant.age = age_cb.getSelectionModel().getSelectedItem();
        Applicant.workexperience= Integer.parseInt(workexpriance_tf.getText());
        Applicant.levelofqualification=cb_qualification.getSelectionModel().getSelectedItem();
        String url=Applicant.profilepicture;
        if(url!=null) {
            url = url.replace("\\", "\\\\");
        }

        DatabaseDriver driver = new DatabaseDriver();
        Connection conn = driver.getDatabaseConnection();
            String sql = "UPDATE applicant SET fullname=?,age=?, phoneNum=?,levelofqualification=?,workexperience=?,areaofspecialization=?,profilepicture=?,gender=? WHERE username='"+Applicant.username+"'; ";
            try (PreparedStatement statement = conn.prepareStatement(sql)) {
                statement.setString(1, Applicant.fullname);
                statement.setInt(2,Applicant.age);
                statement.setString(3,Applicant.phoneNum);
                statement.setString(4, Applicant.levelofqualification);
                statement.setInt(5, Applicant.workexperience);
                statement.setString(6, Applicant.areaofspecialization);;
                statement.setString(7,url);
                statement.setString(8, Applicant.gender);
                statement.executeUpdate();
                if(statement.executeUpdate()!=0) {
                    //setData();
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Confirmation");
                    alert.setHeaderText("Data Saved!");
                    alert.setContentText("Your data has been successfully saved to the database.");
                    ButtonType okButton = new ButtonType("OK");
                    alert.getButtonTypes().setAll(okButton);
                    alert.showAndWait();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

    }//end of method


    private void handleSetProfilePicture() {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter imageFilter = new FileChooser.ExtensionFilter("Image Files (*.png, *.jpg, *.jpeg)", "*.png", "*.jpg", "*.jpeg");
        fileChooser.getExtensionFilters().add(imageFilter);

        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            try {
                Applicant.profilepicture=selectedFile.getAbsolutePath() ;
                // System.out.println(Company.logo);
                // Model.getInstance().getDatabaseDriver().getCompany().setLogo(imagePath);
                //  String url="file:"+Model.getInstance().getDatabaseDriver().getCompany().getLogo();
                //  image=new Image(url,);
                profileImage = new Image(selectedFile.toURI().toString(),173,172,false,true);;
                profilePicture.setImage(profileImage);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//end of method

}