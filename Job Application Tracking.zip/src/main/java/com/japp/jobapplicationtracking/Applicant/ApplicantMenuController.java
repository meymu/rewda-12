package com.japp.jobapplicationtracking.Applicant;

import com.japp.jobapplicationtracking.Model.Applicant;
import com.japp.jobapplicationtracking.Model.Model;
import com.japp.jobapplicationtracking.Views.ApplicantMenuOption;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class ApplicantMenuController implements Initializable {
    public Button logout_btn;
    public Button dashboard_btn;
    public Button profile_btn;

    public  Label Dashboard;

    public void initialize(URL location, ResourceBundle resourceBundle){
        addListener();
    }
    private void addListener(){
    dashboard_btn.setOnAction(event->onDashboard());
    profile_btn.setOnAction(event->onProfile());
    logout_btn.setOnAction(event->onLogbout());
      }

    private void onLogbout(){
        Stage stage= (Stage)Dashboard.getScene().getWindow();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText("Logout Confirmation");
        alert.setContentText("Are you sure you want to log out?");
        Optional<ButtonType> option = alert.showAndWait();
        if (option.get().equals(ButtonType.OK)){

            Model.getInstance().getView().closeStage(stage);
            Model.getInstance().getView().showLoginWindow();
            try {
                Applicant.clearApplicant();
                Model.getInstance().getDatabaseDriver().getDatabaseConnection().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    private void onDashboard(){
    Model.getInstance().getView().getApplicantSelectedMenuItem().set(ApplicantMenuOption.APPLICANT_DASHBOARD);
    }


    private void onProfile(){
        Model.getInstance().getView().getApplicantSelectedMenuItem().set(ApplicantMenuOption.APPLICANT_PROFILE);
    }



}
