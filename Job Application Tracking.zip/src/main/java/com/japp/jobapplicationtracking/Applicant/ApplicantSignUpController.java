package com.japp.jobapplicationtracking.Applicant;

import com.japp.jobapplicationtracking.Model.Applicant;
import com.japp.jobapplicationtracking.Model.DatabaseDriver;
import com.japp.jobapplicationtracking.Model.Model;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.Objects;
import java.util.ResourceBundle;

public class ApplicantSignUpController implements Initializable {
    public Button signup_btn;
    public TextField comform_password_tf;

    public Label Lbl_confirm;
    public Label login_lbl;
    public TextField email_tf;
    public TextField username_tf;
    public TextField password_tf;
    public Label Lbl_password;
    public Label Lbl_username;
    public Label Lbl_email;
    public Button login_btn;
    public Label lbl_error;
private int verify=0;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.signup_btn.setOnAction(event -> onSignUP());
        this.login_btn.setOnAction(event -> {
            Stage stage = (Stage) lbl_error.getScene().getWindow();
            Model.getInstance().getView().showLoginWindow();
            Model.getInstance().getView().closeStage(stage);});


    }//end of method

    private void onSignUP() {
        Verifyuser();
        Connection conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        Stage stage = (Stage) lbl_error.getScene().getWindow();
                Applicant.username = username_tf.getText();
                Applicant.password = password_tf.getText();
                Applicant.email = email_tf.getText();
                if (username_tf.getText().isEmpty() || password_tf.getText().isEmpty() || email_tf.getText().isEmpty() || comform_password_tf.getText().isEmpty()) {
                    lbl_error.setText("please enter all blank space");
                } else if (!comform_password_tf.getText().equals(password_tf.getText())) {
                    lbl_error.setText("password confirmation failed");
                } else {
                    if(this.verify!=0){
                        this.verify=0;
                        lbl_error.setText("the username or email are already token ");
                    }else{
                    Model.getInstance().getView().closeStage(stage);
                    String sql = "INSERT INTO applicant (username, password,email) VALUES (?,?, ?)";
                    try (PreparedStatement statement = conn.prepareStatement(sql)) {
                        statement.setString(1, Applicant.username);
                        statement.setString(2, Applicant.password);
                        statement.setString(3, Applicant.email);
                        statement.executeUpdate();
                        Model.getInstance().getView().showApplicantWindow();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    }}

    }//end of method

                private void Verifyuser(){
                    try {
                        Connection conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
                        String check = "SELECT username from applicant where  username='" + username_tf.getText() + "'OR email='"+email_tf.getText()+"'";
                        String check1 = "SELECT username from Company where  username='" + username_tf.getText() + "'OR email='"+email_tf.getText()+"'";
                        Statement statement=conn.createStatement();
                        ResultSet resultSet1=statement.executeQuery(check1);
                        if (resultSet1.next()) {
                            this.verify=1;
                            resultSet1.close();
                        }

                        ResultSet resultSet2=statement.executeQuery(check);
                        if (resultSet2.next()) {
                            this.verify =1;
                            resultSet2.close();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }//end of method
}
