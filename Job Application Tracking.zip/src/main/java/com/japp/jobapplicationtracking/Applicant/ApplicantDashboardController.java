package com.japp.jobapplicationtracking.Applicant;

import com.japp.jobapplicationtracking.Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ApplicantDashboardController implements Initializable {

    public TableView <Schedule>ScheduleTable;
    public TableColumn<Schedule,String> Tcompanyusername;
    public TableColumn<Schedule,String> Tscheduledate;

    public Label Dashboard;

    public TableView <JobPost>JobTable;
    public TableColumn<JobPost,String> Tdepartement;
    public TableColumn <JobPost,String> TQualification;
    public TableColumn <JobPost,Integer> TNoofemployee;
    public TableColumn <JobPost,Integer> Tworkexpriance;
    public TableColumn <JobPost,String> Tsalary;
    public TableColumn<JobPost,String> Tdeadline;
    public TableColumn<JobPost,String> TjobLocation;

    public TextField tf_search;
    public Button Apply_btn;
    private JobPost selectedPost;

    private ObservableList<JobPost> JobpostList;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        interviewScheduleShowList();
        JobPostShowList();
        onSearch();
       JobTable.setOnMouseClicked(mouseEvent -> JobPostSelected());
        Apply_btn.setOnAction(event -> {
            if (JobTable.getSelectionModel().getSelectedItem() != null) {
                Stage stage = (Stage)Dashboard.getScene().getWindow();
                Model.getInstance().getView().ApplicationWindow();
                Model.getInstance().getView().closeStage(stage);
            }else{
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setHeaderText(" Caution! ");
                alert.setContentText("please select one jobpost .");
                alert.showAndWait();
            }
        });

    }
    public void interviewScheduleShowList(){
        ObservableList<Schedule> scheduledatalist= scheduleList();
        Tcompanyusername.setCellValueFactory(new PropertyValueFactory<>("companyusername"));
        Tscheduledate.setCellValueFactory(new PropertyValueFactory<>("interviewdate"));
        ScheduleTable.setItems(scheduledatalist);

    }
    private ObservableList<Schedule> scheduleList(){
        ObservableList<Schedule> schedulelist = FXCollections.observableArrayList();
        String sql="SELECT *FROM Schedule where applicantusername='"+Applicant.username+"'And interviewdate<>'"+""+"';";
        Connection conn=Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        try{
            PreparedStatement preparedStatement=conn.prepareStatement(sql);
            ResultSet resultSet=preparedStatement.executeQuery();
            Schedule schedule;
            while(resultSet.next()){
                schedule=new Schedule(
                        resultSet.getString("applicantusername"),
                        resultSet.getString("companyusername"),
                        resultSet.getString("postid"),
                        resultSet.getDate("interviewdate"));
                schedulelist.add(schedule);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return schedulelist;
    }

    private void JobPostSelected() {
        selectedPost = JobTable.getSelectionModel().getSelectedItem();
        int num = JobTable.getSelectionModel().getSelectedIndex();
        if ((num - 1) < -1) {
            return;
        }
        Applicant.postid = selectedPost.getPostId();
try {
    Connection conn=Model.getInstance().getDatabaseDriver().getDatabaseConnection();
    PreparedStatement stat= conn.prepareStatement("SELECT  companyName ,headQuarter FROM company  WHERE username='"+selectedPost.getUsername()+"'");
    ResultSet rs=stat.executeQuery();
    while(rs.next()) {
        Company.companyname = rs.getString("companyName");
        Company.companyname = rs.getString("headQuarter");
    }

} catch (SQLException e) {
    e.printStackTrace();
}
    }
    private void onSearch(){
        JobPostShowList();
        FilteredList<JobPost> filteredList=new FilteredList<>(JobpostList, b->true);
        tf_search.textProperty().addListener((observableValue, oldValue, newValue) ->{
            filteredList.setPredicate(jobPost->{
                if(newValue==null||newValue.isEmpty()){
                    return true;
                }
                String lowerCaseFilter=newValue.toLowerCase();
                if(jobPost.getJobLocation().toLowerCase().contains(lowerCaseFilter))
                {
                    return true;
                }else if (jobPost.getQualification().toLowerCase().contains(lowerCaseFilter))
                {
                    return true;
                }
                else if (jobPost.getDepartment().toLowerCase().contains(lowerCaseFilter))
                {
                    return true;
                }
                return  false;
            });
        });
        SortedList<JobPost> sortedList=new SortedList<>(filteredList);
        sortedList.comparatorProperty().bind(JobTable.comparatorProperty());
        JobTable.setItems(sortedList);
    }
    public void JobPostShowList(){
        JobpostList= Model.getInstance().getDatabaseDriver().JobpostListData();

        Tdepartement.setCellValueFactory(new PropertyValueFactory<>("department"));
        TQualification.setCellValueFactory(new PropertyValueFactory<>("qualification"));
        TNoofemployee.setCellValueFactory(new PropertyValueFactory<>("numberOfEmployee"));
        Tworkexpriance.setCellValueFactory(new PropertyValueFactory<>("minWorkExperience"));
        TjobLocation.setCellValueFactory(new PropertyValueFactory<>("jobLocation"));
        Tsalary.setCellValueFactory(new PropertyValueFactory<>("salary"));
        Tdeadline.setCellValueFactory(new PropertyValueFactory<>("deadline"));
        JobTable.setItems(JobpostList);

    }

    public JobPost getSelectedPost() {
        return selectedPost;
    }
}
