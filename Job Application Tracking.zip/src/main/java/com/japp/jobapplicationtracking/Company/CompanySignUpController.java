package com.japp.jobapplicationtracking.Company;

import com.japp.jobapplicationtracking.Model.Company;
import com.japp.jobapplicationtracking.Model.Model;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class CompanySignUpController implements Initializable {


    public TextField tf_email;
    public TextField tf_username;
    public TextField tf_password;
    public Label Lbl_confirm;
    public TextField tf_comform_password;
    public Button signUp_btn;
    public Label login_lbl;
    public Label error_lbl;
    public Button btn_login;
    public Label Lbl_email;
    public Label Lbl_username;
    public Label Lbl_password;

    private int verify=0;

    public void initialize(URL url, ResourceBundle resourceBundle) {

        this.signUp_btn.setOnAction(event -> onSignUP());
        this.btn_login.setOnAction(event ->{
            Stage stage = (Stage) error_lbl.getScene().getWindow();
            Model.getInstance().getView().showLoginWindow();
            Model.getInstance().getView().closeStage(stage);});
    }//end of method

    private void onSignUP() {
        Verifyuser();
        Connection conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();

                Stage stage = (Stage) error_lbl.getScene().getWindow();
                Company.username = tf_username.getText();
                Company.password = tf_password.getText();
                Company.email = tf_email.getText();
                if (Company.username.isEmpty() || Company.password.isEmpty() || Company.email.isEmpty() || tf_comform_password.getText().isEmpty()) {
                    error_lbl.setText("please enter all criteria");
                } else if (!tf_comform_password.getText().equals(Company.password)) {
                    error_lbl.setText("password confirmation failed");
                } else {
                    if(this.verify!=0){
                        this.verify=0;
                        error_lbl.setText("the username or email is already token ");
                    }else{
                    Model.getInstance().getView().closeStage(stage);
                    String sql = "INSERT INTO company (username, password,email) VALUES (?,?, ?)";
                    try (PreparedStatement statement = conn.prepareStatement(sql)) {
                        statement.setString(1, Company.username);
                        statement.setString(2, Company.password);
                        statement.setString(3, Company.email);
                        statement.executeUpdate();
                        Model.getInstance().getView().showCompanyWindow();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }}
                }

    }//end of method

    private void Verifyuser(){
        try {
            Connection conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
            String check = "SELECT username from applicant where  username='" + tf_username.getText() + "'OR email='"+tf_email.getText()+"'";
            String check1 = "SELECT username from Company where  username='" + tf_username.getText() + "'OR email='"+tf_email.getText()+"'";
            Statement statement=conn.createStatement();
            ResultSet resultSet1=statement.executeQuery(check1);
            if (resultSet1.next()) {
                this.verify=1;
                resultSet1.close();
            }
            ResultSet resultSet2=statement.executeQuery(check);
            if (resultSet2.next()) {
                this.verify =1;
                resultSet2.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//end of method
}