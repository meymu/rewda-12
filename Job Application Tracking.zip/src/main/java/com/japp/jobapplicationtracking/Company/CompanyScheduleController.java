package com.japp.jobapplicationtracking.Company;

import com.japp.jobapplicationtracking.Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.function.Predicate;

public class CompanyScheduleController implements Initializable {
    public TableColumn<Schedule,String> applicantname_tv;
    public TableColumn<Schedule,String> postid_tv;
    public TableColumn<Schedule,String> interviewdate_tv;

    public Button Save_btn;
    public Button openfile_btn;

    public TableView<Schedule> Schedulrtable;
    public DatePicker scheduledate_dp=null;
    public Label applicant_tf;
    private ObservableList<Application> allApplicantlist;
    private FilteredList<Application> filteredList;
    private String applicantusername=null;
    private String postid=null;
    Connection conn;
    LocalDate selectedDate=null;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ScheduleShowList();
        scheduledate_dp.setOnAction(event -> {
            selectedDate = scheduledate_dp.getValue();
        });
        Schedulrtable.setOnMouseClicked(mouseEvent -> scheduleSelected());
        Save_btn.setOnAction(event -> onSave());

    }//end of method
    private void onSave(){
        conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
            if( selectedDate==null){
                Alert alert=new Alert(Alert.AlertType.ERROR) ;
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please insert interview date");
                alert.showAndWait();
            }else {
                String sql = "UPDATE schedule SET interviewdate=? WHERE applicantusername='" + this.applicantusername + "' AND postid='" + this.postid + "' ";
                try (PreparedStatement statement = conn.prepareStatement(sql)) {
                    statement.setDate(1, Date.valueOf(selectedDate));
                    if (statement.executeUpdate() != 0) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Confirmation");
                        alert.setHeaderText("Data Saved!");
                        alert.setContentText("Your data has been successfully saved to the database.");
                        ButtonType okButton = new ButtonType("OK");
                        alert.getButtonTypes().setAll(okButton);
                        alert.showAndWait();
                    }
                    ScheduleShowList();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

            }
    }//end of method

    private void scheduleSelected() {
        Schedule schedule = Schedulrtable.getSelectionModel().getSelectedItem();
        int num = Schedulrtable.getSelectionModel().getSelectedIndex();
        if ((num - 1) < -1) {
            return;
        }
        applicant_tf.setText(schedule.getApplicantusername());
        applicantusername=schedule.getApplicantusername();
        postid=schedule.getPostid();

    }//end of method
    public void ScheduleShowList(){
       ObservableList<Schedule> scheduledatalist= scheduleListData();
        ScreenApplicant();
        applicantname_tv.setCellValueFactory(new PropertyValueFactory<>("applicantusername"));
        postid_tv.setCellValueFactory(new PropertyValueFactory<>("postid"));
        interviewdate_tv.setCellValueFactory(new PropertyValueFactory<>("interviewdate"));

        Schedulrtable.setItems(scheduledatalist);

    }//end of method

    public ObservableList<Schedule> scheduleListData(){
        ScreenApplicant();
        ObservableList<Schedule> list = FXCollections.observableArrayList();
        String sql="SELECT *FROM Schedule where companyusername='"+Company.username+"';";
        Connection conn=Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        try{
            PreparedStatement preparedStatement=conn.prepareStatement(sql);
           ResultSet resultSet=preparedStatement.executeQuery();
            Schedule schedule;
            while(resultSet.next()){
                schedule=new Schedule(
                        resultSet.getString("applicantusername"),
                        resultSet.getString("companyusername"),
                        resultSet.getString("postid"),
                        resultSet.getDate("interviewdate"));
                list.add(schedule);
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }//end of method


    public void ScreenApplicant(){

        allApplicantlist = Model.getInstance().getDatabaseDriver().applicationListData();
        ObservableList<JobPost> jobPostslist=Model.getInstance().getDatabaseDriver().JobpostListData();
        filteredList=new FilteredList<>(allApplicantlist);
        filteredList.setPredicate(application->{
for(JobPost jobPost:jobPostslist) {
    if (Objects.equals(application.getJobPostid(), jobPost.getPostId())) {
        String lowerCaseDepartment = jobPost.getDepartment().toLowerCase();
        if (application.getAreaofspecialization().toLowerCase().contains(lowerCaseDepartment)) {
            return true;
        }
        if (application.getLevelofqualification().contains(jobPost.getQualification())) {
            return true;
        } else if (application.getWorkexprience() >= jobPost.getMinWorkExperience()) {
            return true;
        } else {
            return false;
        }
    }
}
    return false;
});

    SortedList<Application> sortedList=new SortedList<>(filteredList);
    try{

        Connection conn=Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        PreparedStatement stat2;
        String sql="Insert into schedule(applicantusername,companyusername,postid ) values(?,?,?) ";
        String sql2="SELECT * FROM schedule WHERE applicantusername= ? And postid=? ";


        for(Application item:sortedList){
            stat2=conn.prepareStatement(sql2);
            stat2.setString(1,item.getApplicantusername());
            stat2.setString(2,item.getJobPostid());
            ResultSet rs=stat2.executeQuery();
            if(!rs.next()){
            PreparedStatement stat=conn.prepareStatement(sql);
             stat.setString(1, item.getApplicantusername());
             stat.setString(2,Company.username);
             stat.setString(3,item.getJobPostid());
            stat.executeUpdate();}
            // stat.addBatch();
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }


    }//end of method




}


