package com.japp.jobapplicationtracking.Company;



import com.japp.jobapplicationtracking.Model.Company;
import com.japp.jobapplicationtracking.Model.DatabaseDriver;
import com.japp.jobapplicationtracking.Model.JobPost;
import com.japp.jobapplicationtracking.Model.Model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import org.w3c.dom.events.MouseEvent;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;

public class CompanyDasnboardController implements Initializable {

    public Button Add_btn;
    public Button Delete_btn;
    public TextField Salary_tf;
    public TextField Search_tf;
    public Button Update_btn;
    public DatePicker datePicker=null;
    public TextField jlocation_tf;
    public Label job_id;
    //public TextField jtitle_tf;
    public TextField noofemployee_tf;
    public TextField postid_tf;
    public TableView<JobPost> PostTable;

    public TableColumn<JobPost, String> Postid_tv;;
    public TableColumn<JobPost, String> jobLocation_tv;
    public TableColumn<JobPost, String> Qualification_tv;
    public TableColumn<JobPost, Integer> Numberofemployee_tv;

    public TableColumn<JobPost, String>Salary_tv;

    public TableColumn<JobPost, String> deadline_tv;
    public TableColumn <JobPost, String> department_tv;
    public TableColumn  <JobPost, Integer>minWorkExperience_tv;
    public TextField minWorkExprience_tf;
    public TextField department_tf;
    public ChoiceBox<String> qualification_tf;
    private final String[] QualificationList={"certificate" ," Degree","Master","PHD"};
    private ObservableList<JobPost> addJobpostList;
    Connection conn=null;
    ResultSet resultSet=null;
    PreparedStatement preparedStatement=null;
    LocalDate selectedDate=null;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        datePicker.setOnAction(event -> {
            selectedDate = datePicker.getValue();
        });
        JobPostShowList();
        qualification_tf.getItems().addAll(this.QualificationList);
        PostTable.setOnMouseClicked(mouseEvent -> JobPostSelected());
        Add_btn.setOnAction(event -> onAdd());
        Delete_btn.setOnAction(event -> onDelete());
        Update_btn.setOnAction(event -> onUpdate());
        onSearch();

    }//end of method

private void onSearch(){
    JobPostShowList();
    FilteredList<JobPost> filteredList=new FilteredList<>(addJobpostList,b->true);
    Search_tf.textProperty().addListener((observableValue, oldValue, newValue) ->{
        filteredList.setPredicate(jobPost->{
            if(newValue==null||newValue.isEmpty()){
                return true;
            }
            String lowerCaseFilter=newValue.toLowerCase();
            if(jobPost.getPostId().toLowerCase().contains(lowerCaseFilter)){
                return true;
            }
            else if(jobPost.getJobLocation().toLowerCase().contains(lowerCaseFilter))
            {
                return true;
            }else if (jobPost.getQualification().toLowerCase().contains(lowerCaseFilter))
            {
                return true;
            }
            else if (jobPost.getDepartment().toLowerCase().contains(lowerCaseFilter))
            {
                return true;
            }
             return  false;
        });
    });
    SortedList<JobPost> sortedList=new SortedList<>(filteredList);
    sortedList.comparatorProperty().bind(PostTable.comparatorProperty());
    PostTable.setItems(sortedList);
}//end of method
    private void JobPostSelected() {
        JobPost jobPost = PostTable.getSelectionModel().getSelectedItem();
        int num = PostTable.getSelectionModel().getSelectedIndex();
        if ((num - 1) < -1) {
            return;
        }
        postid_tf.setText(String.valueOf(jobPost.getPostId()));
        minWorkExprience_tf.setText(String.valueOf(jobPost.getMinWorkExperience()));
        jlocation_tf.setText(String.valueOf(jobPost.getJobLocation()));
        //qualification_tf.getSelectionModel().selectFirst();
        noofemployee_tf.setText(String.valueOf(jobPost.getNumberOfEmployee()));
        department_tf.setText(String.valueOf(jobPost.getDepartment()));
        datePicker.valueProperty().set(LocalDate.parse(String.valueOf(jobPost.getDeadline())));
        Salary_tf.setText(String.valueOf(jobPost.getSalary()));

    }//end of method




    private void onAdd(){
        conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        String sql = "INSERT INTO jobpost (postid,department,joblocation,levelofqualification,numberofemployee,minworkexperience,salary,deadline,username) VALUES (?,?,?,?,?,?,?,?,?); ";

       try {
              if(postid_tf.getText().isEmpty()
                      || department_tf.getText().isEmpty()
                      ||jlocation_tf.getText().isEmpty()
                      ||qualification_tf.getSelectionModel().getSelectedItem()==null
                      ||noofemployee_tf.getText().isEmpty()
                      || minWorkExprience_tf.getText().isEmpty()
                      || Salary_tf.getText().isEmpty()
                      ||selectedDate==null){
               Alert alert=new Alert(Alert.AlertType.ERROR) ;
               alert.setTitle("Error Message");
               alert.setHeaderText(null);
               alert.setContentText("Please insert all information");
               alert.showAndWait();
              }else {
                  String check="SELECT postid from jobpost where postid='"+postid_tf.getText()+"'";
                  Statement stat=conn.createStatement();
                  resultSet=stat.executeQuery(check);
                  if(resultSet.next()){
                      Alert alert=new Alert(Alert.AlertType.ERROR) ;
                      alert.setTitle("Error Message");
                      alert.setHeaderText(null);
                      alert.setContentText("post ID"+postid_tf.getText()+"was already exist!");
                      alert.showAndWait();
                      resultSet.close();
                  }else {
                      preparedStatement = conn.prepareStatement(sql);
                      preparedStatement.setString(1, postid_tf.getText());
                      preparedStatement.setString(2, department_tf.getText());
                      preparedStatement.setString(3, jlocation_tf.getText());
                      preparedStatement.setString(4, (String) qualification_tf.getSelectionModel().getSelectedItem());
                      preparedStatement.setInt(5, Integer.parseInt(noofemployee_tf.getText()));
                      preparedStatement.setInt(6, Integer.parseInt(minWorkExprience_tf.getText()));
                      preparedStatement.setDouble(7, Double.parseDouble(Salary_tf.getText()));
                      preparedStatement.setDate(8, Date.valueOf(selectedDate));
                      preparedStatement.setString(9, Company.username);
                      preparedStatement.executeUpdate();

                      Alert alert=new Alert(Alert.AlertType.INFORMATION) ;
                      alert.setTitle("Information Message");
                      alert.setHeaderText(null);
                      alert.setContentText("Successfully Added!");
                      alert.showAndWait();

                      JobPostShowList();
                      postid_tf.setText("");
                      department_tf.setText("");
                      jlocation_tf.setText("");
                      qualification_tf.getSelectionModel().clearSelection();
                      noofemployee_tf.setText("");
                      minWorkExprience_tf.setText("");
                      Salary_tf.setText("");
                     // datePicker.valueProperty().set(LocalDate.parse("0000-00-00"));
                  }
              }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//end of method



    private void onDelete(){
        Alert alert;
        Connection conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        String sql = "DELETE FROM jobpost WHERE postid='"+postid_tf.getText()+"'";
        try {
            if (postid_tf.getText().isEmpty()
                    && department_tf.getText().isEmpty()
                    &&jlocation_tf.getText().isEmpty()
                    && qualification_tf.getSelectionModel().getSelectedItem()==null
                    &&noofemployee_tf.getText().isEmpty()
                    && minWorkExprience_tf.getText().isEmpty()
                    && Salary_tf.getText().isEmpty()
                    && String.valueOf(selectedDate).isEmpty()) {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please select post item to delete");
                alert.showAndWait();
            } else {
                alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to delete post ID" + postid_tf.getText());
                Optional<ButtonType> option = alert.showAndWait();
                if (option.get().equals(ButtonType.OK)) {
                    preparedStatement = conn.prepareStatement(sql);
                    preparedStatement.executeUpdate();

                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully deleted");
                    alert.showAndWait();

                    JobPostShowList();
                    postid_tf.setText("");
                    department_tf.setText("");
                    jlocation_tf.setText("");
                    qualification_tf.getSelectionModel().clearSelection();
                    noofemployee_tf.setText("");
                    minWorkExprience_tf.setText("");
                    Salary_tf.setText("");
                   // datePicker.valueProperty().set(LocalDate.parse("0000-00-00"));
                }
            }
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//end of method

    public void onUpdate() {
        Alert alert;
       conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
            String sql = "UPDATE jobpost SET department='"+department_tf.getText()+"'" +
                    ",joblocation='"+jlocation_tf.getText()+"'" +
                    ",levelofqualification='"+(String) qualification_tf.getSelectionModel().getSelectedItem()+"'" +
                    ",numberofemployee='"+Integer.parseInt(noofemployee_tf.getText())+"'" +
                    ",minworkexperience='"+Integer.parseInt(noofemployee_tf.getText())+"'" +
                    ",salary='"+Integer.parseInt(minWorkExprience_tf.getText())+"'" +
                    ",deadline='"+Date.valueOf(datePicker.getValue())+"' WHERE postid='"+postid_tf.getText()+"'; ";

        try {
            if (postid_tf.getText().isEmpty()
                    || department_tf.getText().isEmpty()
                    || jlocation_tf.getText().isEmpty()
                    || qualification_tf.getSelectionModel().getSelectedItem() == null
                    || noofemployee_tf.getText().isEmpty()
                    || minWorkExprience_tf.getText().isEmpty()
                    || Salary_tf.getText().isEmpty()
                    || String.valueOf(datePicker.getValue()).isEmpty()) {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please insert all information");
                alert.showAndWait();
            } else {
                alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to update post ID" + postid_tf.getText());
                Optional<ButtonType> option = alert.showAndWait();
                if (option.get().equals(ButtonType.OK)) {
                    preparedStatement = conn.prepareStatement(sql);
                    preparedStatement.executeUpdate();

                    alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Updated");
                    alert.showAndWait();

                    JobPostShowList();
                    postid_tf.setText("");
                    department_tf.setText("");
                    jlocation_tf.setText("");
                    qualification_tf.getSelectionModel().clearSelection();
                    noofemployee_tf.setText("");
                    minWorkExprience_tf.setText("");
                    Salary_tf.setText("");
                    //datePicker.valueProperty().set(LocalDate.parse("0000-00-00"));
                }
            }

            } catch(SQLException e){
                e.printStackTrace();
            }

        }//end of method

public ObservableList<JobPost> JobpostListData(){
ObservableList<JobPost> list =FXCollections.observableArrayList();
String sql="SELECT *FROM jobpost where username='"+Company.username+"';";
conn=Model.getInstance().getDatabaseDriver().getDatabaseConnection();
try{
    preparedStatement=conn.prepareStatement(sql);
    resultSet=preparedStatement.executeQuery();
    JobPost jobPost;
    while(resultSet.next()){
      jobPost=new JobPost(
              resultSet.getString("postid"),
              resultSet.getString("department"),
              resultSet.getString("joblocation"),
              resultSet.getString("levelofqualification"),
              resultSet.getInt("numberOfEmployee"),
              resultSet.getInt("minworkexperience"),
              resultSet.getDouble("salary"),
              resultSet.getDate("deadline"),
              resultSet.getString("username"));
      list.add(jobPost);

    }
    resultSet.close();
    preparedStatement.close();
} catch (SQLException e) {
    e.printStackTrace();
}
return list;
}//end of method


public void JobPostShowList(){
addJobpostList=JobpostListData();

    Postid_tv.setCellValueFactory(new PropertyValueFactory<>("postId"));
    department_tv.setCellValueFactory(new PropertyValueFactory<>("department"));
    Qualification_tv.setCellValueFactory(new PropertyValueFactory<>("qualification"));
    Numberofemployee_tv.setCellValueFactory(new PropertyValueFactory<>("numberOfEmployee"));
    minWorkExperience_tv.setCellValueFactory(new PropertyValueFactory<>("minWorkExperience"));
    jobLocation_tv.setCellValueFactory(new PropertyValueFactory<>("jobLocation"));
    Salary_tv.setCellValueFactory(new PropertyValueFactory<>("salary"));
    deadline_tv.setCellValueFactory(new PropertyValueFactory<>("deadline"));
    PostTable.setItems(addJobpostList);

}//end of method


}


