package com.japp.jobapplicationtracking.Company;


import com.japp.jobapplicationtracking.Model.Company;
import com.japp.jobapplicationtracking.Model.Model;
import com.japp.jobapplicationtracking.Views.CompanyMenuOption;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class CompanyMenuController  implements Initializable{
   public Button btn_setschedule;
    public Label Dashboard_lbl;

    public Button btn_dashboard;

    public Button btn_logout;

    public Button btn_profile;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addListener();
    }
    private void addListener(){
        this.btn_dashboard.setOnAction(event->onDashboard());
        this.btn_setschedule.setOnAction(event->onSetSchedule());
        this.btn_profile.setOnAction(event->onProfile());
        this.btn_logout.setOnAction(event->onLogbout());
    }//end of method

    private void onDashboard(){
        Model.getInstance().getView().getCompanySelectedMenuItem().set(CompanyMenuOption.COMPANY_DASHBOARD);
    }//end of method
    private void onSetSchedule(){
        Model.getInstance().getView().getCompanySelectedMenuItem().set(CompanyMenuOption.SETSCHEDULE);
    }//end of method
    private void onProfile(){
        Model.getInstance().getDatabaseDriver().getCompanyData();
        Model.getInstance().getView().getCompanySelectedMenuItem().set(CompanyMenuOption.COMPANY_PROFILE);
    }//end of method
    private void onLogbout(){
        Stage stage= (Stage)Dashboard_lbl.getScene().getWindow();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText("Logout Confirmation");
        alert.setContentText("Are you sure you want to log out?");
        Optional<ButtonType> option = alert.showAndWait();
        if (option.get().equals(ButtonType.OK)){


            Model.getInstance().getView().closeStage(stage);
            Model.getInstance().getView().showLoginWindow();
            try {
                Company.clearCompany();
                Model.getInstance().getDatabaseDriver().getDatabaseConnection().close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }//end of method


}
