package com.japp.jobapplicationtracking.Company;

import com.japp.jobapplicationtracking.Model.Model;
import javafx.fxml.Initializable;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

import static com.japp.jobapplicationtracking.Views.CompanyMenuOption.*;

public class CompanyController implements Initializable {
    public BorderPane CompanyParent;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Model.getInstance().getView().getCompanySelectedMenuItem().addListener((observableValue, oldValue, newValue) -> {
            switch (newValue){
                case COMPANY_PROFILE->CompanyParent.setCenter(Model.getInstance().getView().getCompanyProfileView());
                case SETSCHEDULE->CompanyParent.setCenter(Model.getInstance().getView().getSetScheduleView());
                default -> CompanyParent.setCenter(Model.getInstance().getView().getCompanyDashboardView());
            }
        });
    }//end of method
}
