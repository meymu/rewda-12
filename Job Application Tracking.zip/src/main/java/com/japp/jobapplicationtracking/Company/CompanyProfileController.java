package com.japp.jobapplicationtracking.Company;

import com.japp.jobapplicationtracking.Model.Applicant;
import com.japp.jobapplicationtracking.Model.Company;
import com.japp.jobapplicationtracking.Model.DatabaseDriver;
import com.japp.jobapplicationtracking.Model.Model;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class CompanyProfileController implements Initializable{
    public Button addPicture_btn;
    public Label companyname_lbl;
    public Label headquarter_lbl;
    public TextField companyname_tf;
    public TextField headquarter_tf;
    public Button btn_save;
    public Button delete_btn;
    public ImageView profilePicture;
    public TextField password_tf;
    public TextField username_tf;
    public TextField tf_email;
    private Image image;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setData();
        btn_save.setOnAction(event -> onSave());
        delete_btn.setOnAction(event -> onDelete());
        addPicture_btn.setOnAction(event -> handleSetProfilePicture());
    }//end of method

    private void handleSetProfilePicture() {
        FileChooser fileChooser = new FileChooser();
        FileChooser.ExtensionFilter imageFilter = new FileChooser.ExtensionFilter("Image Files (*.png, *.jpg, *.jpeg)", "*.png", "*.jpg", "*.jpeg");
        fileChooser.getExtensionFilters().add(imageFilter);

        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            try {
                Company.logo=selectedFile.getAbsolutePath() ;

                image = new Image(selectedFile.toURI().toString(),173,172,false,true);
                profilePicture.setImage(image);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//end of method


    private void onDelete(){
        Alert alert;
        Stage stage = (Stage) companyname_lbl.getScene().getWindow();
        Connection conn =Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        System.out.println(Company.username);
        String sql = "DELETE FROM company WHERE username=?";
        String sql2 = "DELETE FROM jobpost WHERE username=?";
        try {PreparedStatement statement = conn.prepareStatement(sql);
            PreparedStatement statement2 = conn.prepareStatement(sql2);
            alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Message");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to delete your profile");
            Optional<ButtonType> option = alert.showAndWait();

            if (option.get().equals(ButtonType.OK)) {
                statement2.setString(1,Company.username);
                statement.setString(1,Company.username);
                statement2.executeUpdate();
                statement.executeUpdate();
                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("Successfully deleted");
                alert.showAndWait();
                Model.getInstance().getView().applicantShowSignupWindow();
                Model.getInstance().getView().closeStage(stage);
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//end of method

    private void setData(){
        Model.getInstance().getDatabaseDriver().getCompanyData();
        tf_email.setText(Company.email);
        password_tf.setText(Company.password);
        username_tf.setText(Company.username);
        headquarter_tf.setText(Company.headquarterlocation);
        companyname_tf.setText(Company.companyname);
        String url="file:"+Company.logo;
        if (Company.logo!=null){
            image = new Image(url,173,172,false,true);
            profilePicture.setImage(image);
        }
    }//end of method
    private void onSave() {
        String companyname = companyname_tf.getText();
        String headquarter = headquarter_tf.getText();
        String url=Company.logo;
        if(url!=null) {
            url = url.replace("\\", "\\\\");
        }
        Connection conn = Model.getInstance().getDatabaseDriver().getDatabaseConnection();
        String sql = "UPDATE company SET companyName=?,headQuarter=?, logo=? WHERE username=? ";
        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, companyname);
            statement.setString(2, headquarter);
            statement.setString(3, url);
            statement.setString(4, Company.username);
            statement.executeUpdate();
         if(statement.executeUpdate()!=0) {
             setData();
             Alert alert = new Alert(Alert.AlertType.INFORMATION);
             alert.setTitle("Confirmation");
             alert.setHeaderText("Data Saved!");
             alert.setContentText("Your data has been successfully saved to the database.");
             ButtonType okButton = new ButtonType("OK");
             alert.getButtonTypes().setAll(okButton);
             alert.showAndWait();
         }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//end of method
}
