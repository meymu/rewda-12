package com.japp.jobapplicationtracking.Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;

public class DatabaseDriver {
   private final String url = "jdbc:sqlserver://localhost:1433;databaseName=JobapplicationDatabase ;encrypt=true;trustServerCertificate=true";
    private final String username = "rawda";
    private final String password = "1234";
    private Connection connection;
    private ResultSet resultSet=null;
   private Statement statement;
private PreparedStatement preparedStatement;
    public Connection getDatabaseConnection() {
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

                this.connection = DriverManager.getConnection(url, username, password);
            } catch(ClassNotFoundException | SQLException e){
                e.printStackTrace();

            }
        return this.connection;
    }//end of method

    //Applicant
    public void getApplicantData(){
        getDatabaseConnection();
        try{
            statement=this.connection.createStatement();

            resultSet= statement.executeQuery("SELECT * FROM applicant WHERE username='"+Applicant.username+"';");
            while (resultSet.next()) {
                Applicant.areaofspecialization = resultSet.getString("areaofspecialization");
                Applicant.fullname = resultSet.getString("fullname");
                Applicant.phoneNum = resultSet.getString("phoneNum");
                Applicant.age = resultSet.getInt("age");
                Applicant.workexperience = resultSet.getInt("workexperience");
                Applicant.levelofqualification = resultSet.getString("levelofqualification");
                Applicant.profilepicture = resultSet.getString("profilepicture");
                Applicant.gender=resultSet.getString("gender");
                Applicant.email=resultSet.getString("email");
            }
            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//end of method
//company
    public void getCompanyData(){

        getDatabaseConnection();
        try{
            String sql="SELECT  companyName ,headQuarter,logo,email FROM company WHERE username=?;";
            preparedStatement=this.connection.prepareStatement(sql);
            preparedStatement.setString(1,Company.username);
           // preparedStatement.setString(2,Company.password);

            resultSet= preparedStatement.executeQuery();
            while(resultSet.next()) {
                Company.companyname=resultSet.getString("companyname");
                Company.headquarterlocation= resultSet.getString("headquarter");
                Company.logo= resultSet.getString("logo");
                Company.email=resultSet.getString("email");
                }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
           e.printStackTrace();
        }

    }//end of method
    public ObservableList<Application> applicationListData(){
        String qualification;
        String areaofspecialization;
        int workexprience;
        String fullname;
        String username;
        String postId;
        ObservableList<Application> list =FXCollections.observableArrayList();
        String sql="SELECT *FROM application a INNER JOIN jobpost j ON a.jobpostid =j.postid where j.username='"+Company.username+"'  ;";
        connection=getDatabaseConnection();
        try{
            preparedStatement=connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();

            Application application;
            while(resultSet.next()){
                username=resultSet.getString("applicantusername");
                postId= resultSet.getString("jobpostid");
                InputStream coverLetterStream = resultSet.getBinaryStream("coverletter");
                File tempFile = File.createTempFile("cover_letter", "." +"pdf");
                String sql2="SELECT levelofqualification,areaofspecialization,workexperience ,fullname FROM applicant where username='"+username+"';";

                PreparedStatement statement = connection.prepareStatement(sql2);
                ResultSet rs = statement.executeQuery();
                while(rs.next()) {
                    qualification = rs.getString("levelofqualification");
                    areaofspecialization = rs.getString("areaofspecialization");
                    workexprience = rs.getInt("workexperience");
                    fullname = rs.getString("fullname");
                    application=new Application(username,postId, tempFile,qualification,areaofspecialization,workexprience,fullname );
                    list.add(application);
                }


            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }//end of method

    public ObservableList<JobPost> JobpostListData(){
        ObservableList<JobPost> list =FXCollections.observableArrayList();
        String sql="SELECT *FROM jobpost ;";
        connection=getDatabaseConnection();
        try{
           preparedStatement=connection.prepareStatement(sql);
           resultSet=preparedStatement.executeQuery();
            JobPost jobPost;
            while(resultSet.next()){
                jobPost=new JobPost(
                        resultSet.getString("postid"),
                        resultSet.getString("department"),
                        resultSet.getString("joblocation"),
                        resultSet.getString("levelofqualification"),
                        resultSet.getInt("numberOfEmployee"),
                        resultSet.getInt("minworkexperience"),
                        resultSet.getDouble("salary"),
                        resultSet.getDate("deadline"),
                        resultSet.getString("username"));
                list.add(jobPost);

            }
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }//end of method

}
