package com.japp.jobapplicationtracking.Model;

import com.japp.jobapplicationtracking.Views.View;

public class Model {
    private static Model model;
    private final View view;
    private final DatabaseDriver databaseDriver;
    //Applicant
    private Applicant applicant;
    private Company company;

    private Model() {
        this.view = new View();
        this.databaseDriver = new DatabaseDriver();

    }

    public static synchronized Model getInstance() {
        if (model == null) {
            model = new Model();
        }
        return model;
    }

    public View getView() {
        return view;
    }

    public DatabaseDriver getDatabaseDriver() {
        return databaseDriver;
    }


}

