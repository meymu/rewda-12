package com.japp.jobapplicationtracking.Model;

import java.util.Date;

public class JobPost {


    private  String postId;
    private String username;
    private  String department;
    private String qualification;
    private Integer numberOfEmployee;
    private Integer minWorkExperience;
    private String jobLocation;
    private double salary;
    private Date deadline;
public JobPost(String postid,String department,String jobLocation,String qualification,
               Integer numberOfEmployee,Integer minWorkExperience,double salary,Date deadline ,String username){
this.postId=postid;
this.department=department;
this.qualification=qualification;
this.numberOfEmployee=numberOfEmployee;
this.minWorkExperience=minWorkExperience;
this.jobLocation=jobLocation;
this.salary=salary;
this.deadline=deadline;
this.username=username;
}//end of method

    public void setPostId(String postid){
        this.postId=postid;
    }
    public void setDepartment(String department){
        this.department=department;
    }
    public void setJobLocation(String jobLocation){
        this.jobLocation=jobLocation;
    }
    public void setQualification(String qualification){
        this.qualification=qualification;
    }
    public void setNoOfEmployee(Integer numberOfEmployee){
        this.numberOfEmployee=numberOfEmployee;
    }
    public void setMinWorkExperience(Integer minWorkExperience ){
        this.minWorkExperience=minWorkExperience;
    }
    public void setDeadline(Date deadline){
        this.deadline=deadline;
    }
    public void setUsername(String username){this.username=username;}
    public void setSalary(double salary){this.salary=salary; }

public String getPostId(){
        return postId;
}
public String getDepartment(){
        return department;
}
public String getJobLocation(){
        return jobLocation;
}
public String getQualification(){
        return qualification;
}
public Integer getNumberOfEmployee(){
        return numberOfEmployee;
}
public  Integer getMinWorkExperience(){
        return minWorkExperience;
}

public Date getDeadline() {
        return deadline;
    }

public double getSalary() {
        return salary;
    }

public String getUsername() {
        return username;
    }
}
