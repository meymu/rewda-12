package com.japp.jobapplicationtracking.Model;

import javafx.beans.property.StringProperty;

import java.util.List;

public abstract  class User {
    public static String username;
    public static String password;
    public static String email;


        public User(String username,String password,String email) {
            User.username = username;
            User.password = password;
            User.email =email;
        }

}
