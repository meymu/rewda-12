package com.japp.jobapplicationtracking.Model;

import java.util.Date;

public class Schedule {
  private Date  interviewdate;
  private String  applicantusername ;
  private String  companyusername ;
  private String  postid;



    public Schedule(String applicantusername,String companyusername,String postid,Date interviewdate) {
        this.applicantusername = applicantusername;
        this. companyusername=companyusername;
        this.postid=postid;
        this.interviewdate=interviewdate;

    }

  public Date getInterviewdate() {
    return interviewdate;
  }

  public void setInterviewdate(Date interviewdate) {
    this.interviewdate = interviewdate;
  }

  public String getApplicantusername() {
    return applicantusername;
  }

  public void setApplicantusername(String applicantusername) {
    this.applicantusername = applicantusername;
  }

  public String getCompanyusername() {
    return companyusername;
  }

  public void setCompanyusername(String companyusername) {
    this.companyusername = companyusername;
  }

  public String getPostid() {
    return postid;
  }

  public void setPostid(String postid) {
    this.postid = postid;
  }
}
