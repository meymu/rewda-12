package com.japp.jobapplicationtracking.Model;


public class Applicant extends User {
    public static   String fullname;
    public static   int age;
    public static int workexperience;
    public static String gender;
    public static String levelofqualification;
    public static String areaofspecialization;
    public static String profilepicture;
    public static String phoneNum;
    public static String postid;

    public Applicant(String username, String password, String email) {
        super(username, password, email);
    }

    public Applicant(String username, String password,String email, String fullname,String gender, int age,String areaofspecialization,String levelofqualification, int workexperience,String phoneNum ,String photo) {
        super(username, password,email);
        Applicant.fullname =fullname;
        Applicant.age = age;
        Applicant.workexperience =workexperience;
        Applicant.gender =gender;
        Applicant.areaofspecialization=areaofspecialization;
        Applicant.levelofqualification=levelofqualification;
        Applicant.phoneNum=phoneNum;
        Applicant.profilepicture=photo;
    }//end of method
    public static void clearApplicant() {
        new Applicant(null, null,null);
        Applicant.fullname =null;
        Applicant.age = 0;
        Applicant.workexperience =0;
        Applicant.gender =null;
        Applicant.areaofspecialization=null;
        Applicant.levelofqualification=null;
        Applicant.phoneNum=null;
        Applicant.profilepicture=null;
    }//end of method


    public String getUsername() {
        return super.username;
    }
    public String getPassword() {
        return super.password;
    }

}
