package com.japp.jobapplicationtracking.Model;

public class Company extends User {
    public static String companyname=null;
   public   static String headquarterlocation=null;
   public   static String logo=null;


    public Company(String username, String password,String email){
        super( username, password,email);
    };

    public Company(String username, String password,String email,String companyname
            ,String headquarterlocation,String logo) {
        super(username, password, email);
        Company.companyname =companyname;
        Company.headquarterlocation =headquarterlocation;
        Company.logo =logo;

    }
    public static  void clearCompany(){
        new Company(null,null,null);
        Company.companyname =null;
        Company.headquarterlocation =null;
        Company.logo =null;
    }
    public void setCompanyname( String companyname){this.companyname=companyname;}
    public void setHeadquarterlocation( String headquarterlocation){this.headquarterlocation=headquarterlocation;}
    public  void setLogo(String logo){
        this.logo=logo;}
   // public void setQualifiesapplicants(List<String> qualifiesapplicants){this.qualifiesapplicants=qualifiesapplicants;}
    public static String getCompanyname(){return companyname;}
    public static String getHeadquarterlocation(){return headquarterlocation;}
    public static String getLogo() {return logo;}
   // public List<String> getQualifiesapplicants(){return qualifiesapplicants;}

    public void setEmail(String email){
        super.email=email;
    }
    public void setusername(String username){
        super.username=username;
    }
    public void setpassword(String password){
        super.password=password;
    }
    public String getUsername() {
        return super.username;
    }
    public String getPassword() {
        return super.password;
    }
    public String getEmail() {
        return super.email;
    }
}
