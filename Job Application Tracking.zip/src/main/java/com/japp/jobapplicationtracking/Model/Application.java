package com.japp.jobapplicationtracking.Model;


import java.io.File;

public class Application {
        private String applicantusername;
        private String jobPostid;
        private File coverletter;
        private String  levelofqualification;
        private String areaofspecialization;
        private int workexprience;
        private String applicantname;
        public Application(String applicantusername, String jobPostid,File coverletter,String levelofqualification,String areaofspecialization,int workexprience,String appliantname) {
            this.applicantusername = applicantusername;
            this.jobPostid = jobPostid;
            this.coverletter=coverletter;
            this.levelofqualification=levelofqualification;
            this.areaofspecialization=areaofspecialization;
            this.applicantname=appliantname;
        }


    public File getCoverletter() {
        return coverletter;
    }

    public void setCoverletter(File coverletter) {
        this.coverletter = coverletter;
    }

    public String getJobPostid() {
        return jobPostid;
    }

    public void setJobPostid(String jobPostid) {
        this.jobPostid = jobPostid;
    }

    public String getApplicantusername() {
        return applicantusername;
    }

    public void setApplicantusername(String applicantusername) {
        this.applicantusername = applicantusername;
    }

    public String getLevelofqualification() {
        return levelofqualification;
    }

    public void setLevelofqualification(String levelofqualification) {
        this.levelofqualification = levelofqualification;
    }

    public String getAreaofspecialization() {
        return areaofspecialization;
    }

    public void setAreaofspecialization(String areaofspecialization) {
        this.areaofspecialization = areaofspecialization;
    }

    public int getWorkexprience() {
        return workexprience;
    }

    public void setWorkexprience(int workexprience) {
        this.workexprience = workexprience;
    }

    public String getApplicantname() {
        return applicantname;
    }

    public void setApplicantname(String applicantname) {
        this.applicantname = applicantname;
    }
}
