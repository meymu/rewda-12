package com.japp.jobapplicationtracking;


import com.japp.jobapplicationtracking.Model.Model;
import com.japp.jobapplicationtracking.Views.UserRole;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;
;

public  class RoleController implements Initializable{
    public Label role_lbl;
    public Label tologin_lbl;
    public Button login_btn;
    public Button applicant_btn;
    public Button company_btn;

    public void initialize(URL location, ResourceBundle resourceBundle) {

        login_btn.setOnAction(event ->onlogin());
        applicant_btn.setOnAction(event->onApplicant());
        company_btn.setOnAction(event->onCompany());
    }//end of method
    public void onlogin(){
        Stage stage=(Stage)role_lbl.getScene().getWindow();
        Model.getInstance().getView().closeStage(stage);
        Model.getInstance().getView().showLoginWindow();
    }//end of method
    public void onApplicant(){
        Stage stage=(Stage)role_lbl.getScene().getWindow();
        Model.getInstance().getView().setRole(UserRole.APPLICANT);
        Model.getInstance().getView().closeStage(stage);
        Model.getInstance().getView().applicantShowSignupWindow();
    }//end of method
    public void onCompany(){
        Stage stage=(Stage)role_lbl.getScene().getWindow();
        Model.getInstance().getView().setRole(UserRole.COMPANY);
        Model.getInstance().getView().closeStage(stage);
        Model.getInstance().getView().companyShowSignupWindow();
    }//end of method

}