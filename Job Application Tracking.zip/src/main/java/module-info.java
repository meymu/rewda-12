module com.japp.jobapplicationtrackimg {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires de.jensd.fx.glyphs.fontawesome;
    requires mssql.jdbc;


    opens com.japp.jobapplicationtracking to javafx.fxml;
    exports com.japp.jobapplicationtracking;
    exports com.japp.jobapplicationtracking.Applicant;
    exports com.japp.jobapplicationtracking.Company;
    exports com.japp.jobapplicationtracking.Model;
    exports com.japp.jobapplicationtracking.Views;

}